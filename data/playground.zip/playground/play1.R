library(shiny)
library(leaflet)
library(rgdal)

# Load the crime data

rm(list = ls())
setwd("C:/Users/exia/Desktop/shiy_project_playground")
complaint_df <- read.csv("2022_complaint_dataset")
filtered_df <- complaint_df[0:100,]

# Read in the borough boundaries shapefile
boroughs <- readOGR("Borough_Boundaries.geojson")

# Define UI
ui <- fluidPage(
  leafletOutput("map")
)

# Define server
server <- function(input, output) {
  
  # Create leaflet map
  output$map <- renderLeaflet({
    leaflet() %>%
      addProviderTiles("CartoDB.Positron") %>% # Add a tile layer
      addPolygons(data = boroughs, # Add the borough boundaries
                  fillColor = "transparent",
                  color = "black",
                  weight = 2) %>%
      addCircleMarkers(data = filtered_df, # Add the crime data
                       lng = ~Longitude,
                       lat = ~Latitude,
                       radius = 3,
                       color = "red",
                       popup = paste("<b>Complaint Type:</b>", filtered_df$LAW_CAT_CD, "<br>",
                                     "<b>Offense Description:</b>", filtered_df$OFNS_DESC, "<br>",
                                     "<b>Date:</b>", filtered_df$CMPLNT_FR_DT))
  })
  
}

# Run the app
shinyApp(ui, server)
