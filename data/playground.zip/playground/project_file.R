
library(dtplyr)
library(dplyr)
library(DT)
library(lubridate)

library(shiny)
library(leaflet)
rm(list = ls())
setwd("C:/Users/exia/Desktop/shiy_project_playground")
complaint_df <- read.csv("2022_complaint_dataset")
filtered_df <- complaint_df[0:100,]

points <- data.frame(Latitude = filtered_df$Latitude, Longitude = filtered_df$Longitude)

# Define UI
ui <- fluidPage(
  leafletOutput("map")
)

# Define server
server <- function(input, output) {
  
  # Create the map
  output$map <- renderLeaflet({
    leaflet() %>%
      setView(lng = -73.95, lat = 40.7, zoom = 12) %>% # Set the initial view of the map
      addTiles() # Add a tile layer to the map
  })
  
  # Add markers to the map
  observe({
    leafletProxy("map") %>%
      clearMarkers() %>%
      addMarkers(data = filtered_df, 
                 lat = ~Latitude, lng = ~Longitude,
                 ) # Display the complaint type when the user clicks on a marker
  })
  
}

# Run the app
shinyApp(ui, server)

